Zopar poznamok k mojmu zadaniu:
- na otvorenie sidla odporucam prehliadac Safari pre plnu podporu fontov
  (Chrome nepozna font Helvetica Neue Thin a nevedel najst nijaky podobny)
- sidlo som exportoval z GitHub-u, no velkost ZIPka bola 88 MB kvoli fotkam,
  z toho dovodu som si dovolil toto ZIPko rozbalit a zmensit fotky tak, aby
  mali < 1 MB, na localhoste teda fotky budu mensie ako na realnej stranke
- co sa tyka pluginov - last-modified-at pojde len na lokale, na Gite nie
- ikony vo footeri mam zo stranky fontawesome.com, su volne dostupne
- ikonu download na stranke predmetu WP som si robil sam, mam snad 7 verzii
